public class TestRoachPopulation
{
   public static void main(String [] args)
   {
	   /*
	      creating an object named count
	   */
     RoachPopulation count = new RoachPopulation(10); // calling constructor here

     System.out.println(count);


     count.setDoubling(10);
     System.out.println("Double population of roaches="+count.getDoubling()); //getting double value from RoachPopulation class

      count.setSpraying(count.getDoubling());
     System.out.println("Population of roaches after Spraying="+count.getSpraying()); // getting reduced population





   }


}