/*
  Roach population Assignment
*/
/**
 @author Gurveer Singh
 @version 1.1
*/
public class RoachPopulation
{
     private int roach; // instance variable

/**
Roach population method for displaying initial value
@param  r

*/
    public RoachPopulation(int r)
    {
	 this.roach = r;
     //System.out.println("Initial Population of roaches="+roach);
    }
/**
set doubling  method for displaying double value
@param  roach
@return int
*/
    public void setDoubling(int roach)
    {
      this.roach = 2*roach;
    }
/**
get doubling  method for returning double value
@return int
*/
    public int getDoubling()
    {
       return roach;
    }
/**
set spraying  method for displaying reduced value
@param  roach
*/
    public void setSpraying(int roach)
    {
      this.roach = (roach-3*(roach/10)); // do spraying three times and reduced by 10% population
    }
/**
get doubling  method for returning reduced value
@return int
*/
    public int getSpraying()
    {
      return roach;
    }
/**
to string  method for displaying inital value
@return string
*/
    public String toString()
    {
       return("Initial Population of roaches="+roach);// to string method will automatically call
    }


}